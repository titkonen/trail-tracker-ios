import UIKit
import MapKit

class MulticolorPolyline: MKPolyline {
  var color = UIColor.black
}

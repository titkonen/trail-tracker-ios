import CoreLocation

class LocationManager {
  static let shared = CLLocationManager()
  
  private init() { }
}
